/*******************************************************************************
/ * \ / * \ / * \ / * \ / * \ / * \ / * \ / * \ / * \ / * \ / * \ / * \ / * \ /*
 * * * * W * E * L * C * O * M * E * * * T * O * * * T * H * E * * * * * * * * * 
* * * * * * * * * * * * * P * R * O * G * R * A * M * * * * * * * * * * * * * *
\ * / \ * / \ * / \ * / \ * / \ * / \ * / \ * / \ * / \ * / \ * / \ * / \ * / \.
*******************************************************************************\


/*sets a mutual package for all associated .java docs in this program.*/
package com.mycompany.javaproject;



/*java.io allows for the use of exception handling in the Conditions class*/
import java.io.*;

/*the java.awt table allows for the use of layouts and events (such as clicking
on a button*/
import java.awt.FlowLayout;
import java.awt.LayoutManager;
import java.awt.Window;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.util.logging.Level;
import java.util.logging.Logger;
import static java.awt.Component.CENTER_ALIGNMENT;
import java.awt.Dimension;
import java.awt.Font;
import java.awt.event.WindowAdapter;
import java.awt.event.WindowEvent;


/*javax.swing allows for the implementation of a variety of GUI components
to include, but not limited to, frames, buttons, and panels*/
import javax.swing.JButton;
import javax.swing.JFrame;
import javax.swing.JOptionPane;
import javax.swing.JPanel;
import javax.swing.*;
import javax.swing.SwingUtilities;

/*******************************************************************************
Class: Conditions
Use: Creates a windowed interface for the user to perform conversions from
military time to standard time via the parameters outlined both in the Conditions 
class and in the Time class and loops the program repetitively until either
the primary window is destroyed or you choose the, "No," button on the window
that asks if you would like to perform another conversion

Contribution: Brandon Sabrsula
(Additional Contributions: Aaron George contributed the initial conditional 
statements for each of these functions, however, I have shorthanded a good 
majority of the original statements to condense the logic down into a more
manageable class and implemented both the awt and the swing packages entirely
by myself)
*.
*******************************************************************************/
public class Conditions {
/*******************************************************************************
Class: Conditions
Function: LengthChecker()
Use: Checks to ensure that the length of user input is exactly 5 characters;
outputs an error message in the event that it is not
Contribution: Brandon Sabrsula
*.
     * @param userInput
     * @return 
*******************************************************************************/
    public static boolean LengthChecker(String userInput){
        if(userInput.length() != 5){
            JOptionPane.showMessageDialog(null, "Please enter exactly 5 " +
                    "characters, including the colon (# # : # #). Click 'Let's start"
                        +" converting' if you'd like to try again.",
                    "Error: Incorrect Length", JOptionPane.WARNING_MESSAGE);
            return true;//breaks loop iteration in createUI() if the length of the user input doesn't equal 5
        }
        else{
            return false;//continues loop in createUI() if user input equals 5
        }
    }
    
    
/*******************************************************************************
Class: Conditions
Function: colon()
Use: Checks to see if the colon is exactly at the third position in the user's
input; outputs a Colon Placement error message in the event that the placement
of the colon is invalid
Contribution: Brandon Sabrsula
*.
     * @param userInput
     * @return 
*******************************************************************************/
    public static boolean colon(String userInput){
                
        if(userInput.charAt(2) != ':'){
            System.out.println("The user did not properly format the statement.");
            JOptionPane.showMessageDialog(null, "Please only enter a colon in "+
                    "the middle of the 5 characters. Click 'Let's start " +
                    "converting' if you'd like to try again.",
                                    "Error: Incorrect Colon Placement", 
                                    JOptionPane.WARNING_MESSAGE);
            return true;//breaks loop in createUI() if user input doesn't have a
            //colon in the 3rd position
        }
        else{
            return false;//continues loop in createUI() if user input does have
            //a colon in the 3rd position
        }
    }
    
    
/*******************************************************************************
Class: Conditions
Function: setTimeFormat()
Use: sets hours and minutes equivalent to substrings of userInput, turns the
substring characters into integer values, then states that if getHourStatus() and
getMinStatus() from instance of Time created in this class are both true, return
the properly-formatted time for the military time input; else if getHourStatus()
is false output an Hours Error message, else if getMinStatus() is false, output
a Minutes Error message
Contribution: Brandon Sabrsula
*.
     * @param userInput
     * @param e
     * @return 
     * @throws java.lang.InterruptedException 
*******************************************************************************/
    public static boolean setTimeFormat(String userInput, ActionEvent e) throws 
            InterruptedException{
        
        //Initializing and setting local variables.
        int hours = Integer.parseInt(userInput.substring(0,2));
        int minutes = Integer.parseInt(userInput.substring(3,5));
        boolean bool = false;
        Object[] options = {"OK"};
        
        //Initializing and setting local instances, updating instance of time
        //to instance of JLabel to append font to JLabel for reader clarity.
        Time timeTable = new Time(hours, minutes);
        JLabel input = new JLabel(timeTable.toString());
        input.setFont(new Font("Arial", Font.PLAIN, 18));
        
        
        if(timeTable.getHourStatus(hours) && timeTable.getMinStatus(minutes)){
            JOptionPane.showMessageDialog(null, input);
            bool = false;//If user input is within tolerance for both hours and
            //minutes, show the user's input and continue the current loop
        }//iteration in createUI().
        else if(!(timeTable.getHourStatus(hours)) || !(timeTable.getMinStatus(minutes))){
            int optionPane = JOptionPane.showOptionDialog(null, "Please enter hours between" +
                    " 00 and 23 and minutes between 00 and 59. Click 'Let's" +""
                    + " start converting' if you'd like to try again.", 
                    "Time Exception Error", JOptionPane.PLAIN_MESSAGE,
                    JOptionPane.WARNING_MESSAGE, null, options, options[0]);
            System.out.println("User Error: Either hours or minutes were " +
                    "Incorrect: \n> Hours = "+hours+" "+
                    "\n> Minutes = "+minutes);//If user's hour or minute inputs
            //are incorrect, but previous conditions are met in the loop,
            //outputs a terminal message with information and a windowed error message.
            switch(optionPane){
                case 0:
                    System.out.println("User pressed OK in setTimeFormat() error window.");
                    return true;//In the event of user pressing okay, output a
                    //terminal message and return true to loop iteration in createUI().
                case -1:
                    System.out.println("User press red 'X' in setTimeFormat() error window.");
                    return true;//In the event of user pressing red 'X', output
                    //a terminal message and return true to loop iteration in createUI().
            }
        }
        System.out.println("This line only prints when if condition is met " +
                "in setTimeFormat() time display window.");
        return bool;//Prints a terminal message for if statement and returns
        //terminal message and bool only if the if conditions are met.
    }//End setTimeFormat()
    
    
/*******************************************************************************
Class: Conditions
Function: Again()
Use: Accepts ActionEvent e from createUI() in Conditions class; sets a switch on
optionPane: if Yes is clicked optionPane becomes 0 and function returns true; if
No is clicked, optionPane becomes 1 and the entire program terminates; if some
other condition occurs, the default is an Invalid Response error message
Contribution: Brandon Sabrsula
*.
     * @param e
     * @return 
*******************************************************************************/
    public static boolean Again(ActionEvent e){
        int optionPane = JOptionPane.showOptionDialog(null, "Would you like to"+
                " perform another conversion?", "Loopback on Click",
                JOptionPane.YES_NO_OPTION, JOptionPane.INFORMATION_MESSAGE,
                null, null, null);
        switch (optionPane) {
            case 0:
                System.out.println("User pressed YES in Again()");
                return true;
            case 1:
                System.out.println("User pressed No in Again()");
                JComponent comp = (JComponent) e.getSource();
                Window win = SwingUtilities.getWindowAncestor(comp);
                win.dispose();
                return false;
            case -1:
                System.out.println("User pressed red 'X' in Again(). This " + 
                        "action is designed to close the program.");
                JComponent compX = (JComponent) e.getSource();
                Window winX = SwingUtilities.getWindowAncestor(compX);
                winX.dispose();
                return false;
            default:
                JOptionPane.showMessageDialog(null,"You input an invalid response. " +
                        "Click 'Let's start converting' if you'd like to try again",
                        "Error: Invalid Response", JOptionPane.WARNING_MESSAGE);
                return false;
        }
    }
    
    
/*******************************************************************************
Class: Conditions
Function: creatUI()
Use: Creates the components of the main interface, calls on the other functions
in the conditions class to perform their functionality once you click the,
"Let's start converting," button and creates an ActionEvent e that gets passed
to Again so that Again can destroy the program in the event that the user does
not wish to utilize the program anymore; if the bool return of again is set to
true, then the user receives a window requesting a 5-char military time and if
the user input is in an invalid format, the program throws a Format Error message
Contribution: Brandon Sabrsula
*.
     * @param frame
     * @throws java.io.IOException
*******************************************************************************/
    public static void createUI(final JFrame frame) throws IOException{
        
        JPanel panel = new JPanel();
        LayoutManager layout = new FlowLayout();
        panel.setLayout(layout);
        
        JButton button = new JButton("Let's start converting!");
        
        //On-click listener that only operates the loop if the 'Let's start
        //converting button is pressed. Once pressed, the loop first takes a
        //user input, then performs a lengthy series of checks between 2 classes
        //to ensure there are no errors before returning the properly formatted
        //time. If all checks are good, asks the user if they would like to
        //continue. Will destroy program if user chooses red 'X'.
        button.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                boolean again = true;
                String userInput = JOptionPane.showInputDialog("Enter 5-"
                        + "char military time (XX:XX): ");
                while(again){
                    try{
                        if(LengthChecker(userInput)){
                            break;
                        }
                        if(colon(userInput)){
                            createWindow();
                            break;
                        }
                        if(setTimeFormat(userInput, e)){
                            break;
                        }
                        again = Again(e);
                        if(again == true){
                            userInput = JOptionPane.showInputDialog("Enter 5-char military time"
                                    + " (XX:XX):");
                        }
                    }
                    //In the event that an error occurs in try, handles previously
                    //unhandled number formatting errors, IOExceptions, and
                    //Interrupt exceptions by alerting the user and breaking
                    //the current loop iteration.
                    catch(NumberFormatException g){
                        System.out.println("Format Error: User input incorrect format");
                        JOptionPane.showMessageDialog(null, "Please enter 2 numbers"
                                + " a colon and 2 numbers (XX:XX). Click 'Let's start"
                                +" converting' if you'd like to try again", "Format Error",
                                JOptionPane.WARNING_MESSAGE);
                        break;
                    } catch (IOException | InterruptedException ex) {
                        Logger.getLogger(Conditions.class.getName()).log(Level.SEVERE, null, ex);
                        break;
                    }
                }//End while
            }
        });//End onClick functionality for conversion button
            

            /*Creates new iteration of JLabel class called click, adds click to the
            primary panel, adds the event button to the primary panel, adds content
            panel to frame and centers it on the frame.*/
            JLabel click = new JLabel("Click the button to begin converting!");
           
            panel.add(click);
            panel.add(button);
            panel.setAlignmentX(CENTER_ALIGNMENT);
            panel.setAlignmentY(CENTER_ALIGNMENT);
            
            frame.getContentPane().add(panel);
        } //End createUI

    public static void createWindow() throws IOException{
        JFrame frame = new JFrame("Military Time Conversion Tool");
        frame.setDefaultCloseOperation(JFrame.DO_NOTHING_ON_CLOSE);
        frame.addWindowListener(new WindowAdapter(){
            @Override
            public void windowClosing(WindowEvent e){
                System.out.println("Program was closed.");
                e.getWindow().dispose();
            }
        });
        createUI(frame);//call to panel creation function
        
        frame.setResizable(false);
        frame.setSize(new Dimension(560, 200));
        frame.setLocationRelativeTo(null);
        frame.setVisible(true);
    }//End CreateUI function
    
    
}//End Conditions class