/*******************************************************************************
Class: TimeDemo 
Use: Calls on Conditions class to create windows.
Contribution: Brandon Sabrsula
*******************************************************************************/

package com.mycompany.javaproject;/*sets a mutual package for all associated
.java docs in this program.*/


import java.io.*;//allows for the use of exception handlers
        
public class TimeDemo {
/*******************************************************************************
Class: TimeDemo
Function: Main()
Use: Calls on function conditionalPrint in TimeDemo
Contribution: Brandon Sabrsula
* @param args
* @throws java.io.IOException
*******************************************************************************/
    
    public static void main(String[] args) throws IOException{
        //Calls function createWindow() from class Conditions
        Conditions.createWindow();
    }
}//End TimeDemo Class