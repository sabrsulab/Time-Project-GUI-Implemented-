package com.mycompany.javaproject;
/*******************************************************************************
Class: Time
Use: Performs minor calculations based on user input to instruct the 
Contribution: Aaron George || headers courtesy of Brandon Sabrsula
*.
*******************************************************************************/
public class Time {
//Sets global variables to private and static (if necessary).
    private static int hours;
    private static int minutes;
    private static  String timeOfDay;
    private boolean hourStatus;
    private boolean minStatus;
    private final int hrsUnchanged;
    
/*******************************************************************************
Class: Time
Function: Time()
Use: Sets the value of minutes, hours, and hrsUnchanged equivalent to some piece
of user input
Contribution: Aaron George || headers courtesy of Brandon Sabrsula
*.
     * @param h
     * @param m
*******************************************************************************/
    public Time(int h, int m){        
            minutes = m;
            hours = h;
            hrsUnchanged = h;
    }//End Time()
    
    
/*******************************************************************************
Class: Time
Function: getHourStatus()
Use: Returns true if hours is greater than 0 AND hours is less than 23 otherwise
returns false
Contribution: Aaron George || headers courtesy of Brandon Sabrsula
*.
     * @param h
     * @return 
*******************************************************************************/
    public boolean getHourStatus(int h){
        if(hrsUnchanged >= 0 && hrsUnchanged <= 23){
            return true;
        }
        else{
            return false;
        }
    }//End getHourStatus()
    

/*******************************************************************************
Class: Time
Function: getTime()
Use: Determines if the hrsUnchanged variable is greater than or equal to 12; If
it is, returns "P.M." if it isn't returns, "A.M."
Contribution: Aaron George || headers courtesy of Brandon Sabrsula
*.
     * @param m
     * @return 
*******************************************************************************/
    public boolean getMinStatus(int m){
        minStatus = (minutes >= 0 && minutes <= 59);
        return minStatus;
    }//End getMinStatus()
    
    
/*******************************************************************************
Class: Time
Function: getMinutes()
Use: Returns minutes when called
Contribution: Aaron George || headers courtesy of Brandon Sabrsula
*.
     * @return 
*******************************************************************************/
    public int getMinutes(){
        return minutes;
    }//End getMinutes()
    
    
/*******************************************************************************
Class: Time
Function: getHours()
Use: Determines if the hours variable is greater than 12 | If
it is, function returns hours - 12; if it's equal to 0 function returns 12; 
otherwise returns the original value of hours | Exception handling performed
elsewhere
Contribution: Aaron George || headers courtesy of Brandon Sabrsula
*.
     * @return 
*******************************************************************************/
    public int getHours(){
        if(hours > 12)
        {
            hours = hours - 12;
        }
        else if(hours == 0)
        {
            hours = 12;
        }
        return hours;
    }//End getHours()
    
    
/*******************************************************************************
Class: Time
Function: getTime()
Use: Determines if the hrsUnchanged variable is greater than or equal to 12; If
it is, returns "P.M." if it isn't returns, "A.M."
Contribution: Aaron George || headers courtesy of Brandon Sabrsula
*.
     * @return 
*******************************************************************************/    
    public String getTime(){
        if(hrsUnchanged >= 12){
            return "p.m.";
        }
        else{
            return "a.m.";
        }
    }//End getTime
    
    
/*******************************************************************************
Class: Time
Function: toString()
Use: Formats and returns the hours, minutes, and whether the time is occurring
in the morning or the afternoon
Contribution: Aaron George || headers courtesy of Brandon Sabrsula
*.
*******************************************************************************/
    @Override
    public String toString(){
        return String.format("%02d", getHours()) + ":" + String.format("%02d",
                getMinutes()) + " " + getTime();
    }//End toString()

}//End Time class